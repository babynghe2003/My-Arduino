This repository was copied directly from,
https://github.com/Lynxmotion/Arduino-PS2X
but fixes some annoying type errors that cause warnings in the Arduino 
compiler.
